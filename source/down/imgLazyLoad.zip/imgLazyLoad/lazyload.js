 (function($) {
     function showImg(timer){
        var winHeight = $(window).height()
        var scrollHeight = $(window).scrollTop()
        var t = timer||500
        var imgs = $('img[data]')
        this.find(imgs).each(function() {
            if(($(this).offset().top < winHeight + scrollHeight)&&!$(this).attr("loaded")){
                setTimeout(()=>{
                    $(this).attr('src', $(this).attr('data'));
                    $(this).attr('loaded', "true");
                },t)
            };
        })
     }
     $.fn.extend({
         "imgLazyLoad":function(timer){
            var el = this
            showImg.call(el,timer);
            $(window).on('scroll',function(){
                showImg.call(el,timer);
            })
        }
     })
})(jQuery);